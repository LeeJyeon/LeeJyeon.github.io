package coopang_250907.concurrency;

import java.util.concurrent.locks.Lock;

public class FooBarAlternative {

    class FooBar {
        private int n;
        volatile boolean isFooable = true;

        public FooBar(int n) {
            this.n = n;

        }

        private Lock lock;

        public void foo(Runnable printFoo) throws InterruptedException {

            for (int i = 0; i < n; i++) {
                synchronized (this) {
                    while (!isFooable) {
                        wait();
                    }
                    // printFoo.run() outputs "foo". Do not change or remove this line.
                    printFoo.run();
                    isFooable = false;
                    notifyAll();
                }
            }

        }

        public void bar(Runnable printBar) throws InterruptedException {

            for (int i = 0; i < n; i++) {
                synchronized (this) {
                    while (isFooable) {
                        wait();
                    }
                    // printBar.run() outputs "bar". Do not change or remove this line.
                    printBar.run();
                    isFooable = true;
                    notifyAll();
                }
            }
        }
    }
}
