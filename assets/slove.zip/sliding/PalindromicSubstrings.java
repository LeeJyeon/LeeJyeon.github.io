package coopang_250907.sliding;

public class PalindromicSubstrings {

    static int count1 = 0;

    public static void main(String[] args) {
        System.out.println(countSubstrings("abc"));
    }

    public static int countSubstrings(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            for (int j = i; j < s.length(); j++) {
                if (isPalindrome(s, i, j)) {
                    count++;
                    if (count1 == 2) {
                        count1 = 0;
                        break;
                    }
                }
            }
        }
        return count;
    }

    public static boolean isPalindrome(String s, int i, int j) {
        while (i <= j) {
            if (s.charAt(i) != s.charAt(j)) {
                count1++;
                return false;
            }
            i++;
            j--;
        }
        return true;
    }


}
