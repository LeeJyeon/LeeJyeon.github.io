### Algorithms & Data Structures

| Problem                                | Topic                          | Difficulty |
|----------------------------------------|--------------------------------|------------|
| Two Sum                                | Hash Table                     | Easy       |
| Valid Anagram                          | String, Hash Table             | Easy       |
| Merge Intervals                        | Sorting, Greedy                | Medium     |
| Group Anagrams                         | Hash Table                     | Medium     |
| First Missing Positive                 | Array Manipulation             | Hard       |
| Kth Largest Element in Array           | Heap                           | Medium     |

### Trees & Graphs
| Problem                                | Topic                          | Difficulty |
|----------------------------------------|--------------------------------|------------|
| Number of Islands                      | DFS/BFS                        | Medium     |
| Lowest Common Ancestor of a Binary Tree| Tree Traversal                 | Medium     |

### Strings & Sliding Window
| Problem                                | Topic                          | Difficulty |
|----------------------------------------|--------------------------------|------------|
| Serialize and Deserialize Binary Tree  | Tree, Design                   | Hard       |
| Longest Substring Without Repeating Characters | Sliding Window          | Medium     |
| Find All Anagrams in a String          | Sliding Window                 | Medium     |
| Palindromic Substrings                 | Dynamic Programming            | Medium     |

### System Design
| Problem                                | Topic                          | Difficulty |
|----------------------------------------|--------------------------------|------------|
| LRU Cache                              | Design, LinkedHashMap          | Medium     |
| Design a Distributed Cache             | System Design                  | N/A        |
| Design a Real-Time Inventory System    | System Design                  | N/A        |
| Design a Notification System           | System Design                  | N/A        |
| Design a URL Shortener                 | System Design                  | N/A        |

### Concurrency
| Problem                                | Topic                          | Difficulty |
|----------------------------------------|--------------------------------|------------|
| Print in Order                         | Multithreading                 | Easy       |
| FooBar Alternating                     | Multithreading                 | Medium     |
