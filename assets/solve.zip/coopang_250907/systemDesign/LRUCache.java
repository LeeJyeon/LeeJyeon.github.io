package coopang_250907.systemDesign;

import java.util.HashMap;

public class LRUCache {

    int capacity;
    HashMap<Integer, Node> cache;
    Node head;
    Node tail;

    // head(고정), 최신 , .... , 삭제예정 ,tail(고정)
    // -> next
    // <- previous
    public LRUCache(int capacity) {
        this.capacity = capacity;
        cache = new HashMap<>();
        head = new Node(0, 0);
        tail = new Node(0, 0);
        head.next = tail;
        tail.previous = head;
    }


    public int get(int key) {
        if (!cache.containsKey(key)) {
            return -1;
        }

        Node present = cache.get(key);
        deleteNode(present);
        addToHead(present);
        return present.value;
    }

    private void addToHead(Node node) {
        Node tmp = head.next;

        tmp.previous = node;
        node.next = tmp;

        node.previous = head;
        head.next = node;
    }

    private void deleteNode(Node node) {
        node.previous.next = node.next;
        node.next.previous = node.previous;
    }

    public void put(int key, int value) {

        Node node;
        if (cache.containsKey(key)) {
            node = cache.get(key);
            node.value = value;
            deleteNode(node);
            addToHead(node);
            return;
        }

        node = new Node(key, value);


        addToHead(node);
        cache.put(key, node);

        if (cache.size() > capacity) {
            Node delete = tail.previous;
            deleteNode(delete);
            cache.remove(delete.key);
        }
    }

    class Node {
        int key;
        int value;
        Node previous;
        Node next;

        public Node(int key, int value) {
            this.key = key;
            this.value = value;
            this.previous = null;
            this.next = null;
        }
    }
}