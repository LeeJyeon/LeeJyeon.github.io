package coopang_250907.algorithm;

import java.util.Arrays;

public class KthLargestElementInArray {
    public static void main(String[] args) {

        System.out.println(findKthLargest(new int[]{3,2,1,5,6,4}, 2));
    }
    public static int findKthLargest(int[] nums, int k) {
        Arrays.sort(nums);
        return nums[nums.length - k];
    }
}
