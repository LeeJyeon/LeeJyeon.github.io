package coopang_250907.algorithm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MergeIntervals {

    public static void main(String[] args) {
        merge(new int[][]{{1,3},{2,6},{8,10},{15,18}});
    }

    public static int[][] merge(int[][] intervals) {

        Arrays.sort(intervals, Comparator.comparingInt(a -> a[0]));

        List<int[]> result = new ArrayList<>();

        int[] before = intervals[0];

        for (int i = 1; i < intervals.length; i++) {
            // 이어붙이기
            if (intervals[i][0] <= before[1]) {
                before[1] = Math.max(before[1], intervals[i][1]);
            } else {
                result.add(before);
                before = intervals[i];
            }
        }

        result.add(before);
        return result.toArray(new int[result.size()][]);
    }

}
