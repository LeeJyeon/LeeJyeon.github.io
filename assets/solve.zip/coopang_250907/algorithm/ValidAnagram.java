package coopang_250907.algorithm;

public class ValidAnagram {

    public static void main(String[] args) {
        System.out.println(isAnagram("anagram", "nagaram"));
    }

    public static boolean isAnagram(String s, String t) {
        if (s.length() != t.length()) return false;

        int[] map = new int[26];

        for (int i = 0; i < s.length(); i++) {

            int a = s.charAt(i);
            int b = t.charAt(i);

            if(a==b){
                continue;
            }

            map[a - 'a']++;
            map[b - 'a']--;
        }

        for (int i : map) {
            if(i !=0 ) return false;
        }
        return true;
    }
}
