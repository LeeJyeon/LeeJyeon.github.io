package coopang_250907.algorithm;

import java.util.HashMap;

public class TwoSum {

    public static void main(String[] args) {
        twoSum(new int[]{2, 7, 11, 15}, 9);
    }

    public static int[] twoSum(int[] nums, int target) {

        HashMap<Integer,Integer> map = new HashMap();

        for (int i = 0; i < nums.length; i++) {

            // 타겟 계산에 필요한 숫자를 찾으면
            if(map.containsKey(target - nums[i])) {
                // 그위치와 지금의 위치를 반환함
                return new int[]{map.get(target - nums[i]), i};
            }
            // 숫자위치와 인덱스를 보관함
            map.put(nums[i], i);
        }
        return new int[]{0,0};
    }

}
